clear
echo "******* TorProxy Installer ********"
echo ""
echo "=====> Installing macchanger "
sudo yum -y -q macchanger
echo "=====> Installing tor bundle "
sudo yum -y -q tor
echo "=====> Installing TorProxy "
sudo cp torproxy /usr/bin/torproxy
sudo chmod +x /usr/bin/torproxy
echo "=====> Done "
echo "=====> Open terminal and type 'torproxy' for usage "
