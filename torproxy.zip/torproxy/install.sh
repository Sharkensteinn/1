clear
echo "******* TorProxy Installer ********"
echo ""
echo "=====> Installing macchanger "
sudo apt-get install macchanger -y -qq
echo "=====> Installing tor bundle "
sudo apt-get install tor -y -qq
echo "=====> Installing TorProxy "
sudo cp torproxy /usr/bin/torproxy
sudo chmod +x /usr/bin/torproxy
echo "=====> Done "
echo "=====> Open terminal and type 'torproxy' for usage "
