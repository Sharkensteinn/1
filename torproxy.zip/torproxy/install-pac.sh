clear
echo "******* TorProxy Installer ********"
echo ""
echo "=====> Installing macchanger "
sudo pacman -S --quiet --noconfirm --needed macchanger
echo "=====> Installing tor bundle "
sudo pacman -S --quiet --noconfirm --needed tor
echo "=====> Installing TorProxy "
sudo cp torproxy-arch /usr/bin/torproxy
sudo chmod +x /usr/bin/torproxy
echo "=====> Done "
echo "=====> Open terminal and type 'torproxy' for usage "
